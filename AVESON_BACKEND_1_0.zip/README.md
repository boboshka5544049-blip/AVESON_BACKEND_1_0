# AVESON BACKEND 1.0

Birinchi real backend qatlam: **Artist → Backend → Admin**.

## Nimalar bor

- PostgreSQL
- Artist registration/login
- Admin login
- bcrypt password hashing
- server-side sessions
- Artist/Admin RBAC
- Release upload: audio + cover
- Release metadata
- Release status workflow:
  - DRAFT
  - PENDING_REVIEW
  - CHANGES_REQUIRED
  - APPROVED
  - REJECTED
  - RELEASED
- Admin release queue
- Admin review endpoint
- Artist faqat o'z release'larini ko'radi
- Admin barcha release'larni ko'radi
- Audio/cover local storage
- Helmet + rate limit + CORS

## Local ishga tushirish

1. Node.js 20+ va Docker o'rnating.
2. `.env.example` ni `.env` qilib nusxalang.
3. Terminalda:

```bash
docker compose up -d postgres
npm install
npm start
```

API:
`http://localhost:8080`

Health:
`GET /api/health`

## Admin yaratish

`.env` ichiga vaqtincha:

```env
ADMIN_BOOTSTRAP_KEY=CHANGE_THIS_TO_A_LONG_RANDOM_KEY
```

Serverni qayta ishga tushiring.

Keyin `/api/admin/bootstrap` ga `x-bootstrap-key` header bilan admin email/password yuboriladi.

Bootstrap tugagach `ADMIN_BOOTSTRAP_KEY` ni o'zgartiring yoki olib tashlang.

## Muhim

Bu 1.0 — production deploymentdan oldingi backend foundation.

Keyingi bosqich:
1. Artist Android app → `/api/login`
2. Artist Android app → multipart `/api/releases`
3. Admin Android app → `/api/admin/queue`
4. Admin approve/reject → `/api/releases/:id/review`
5. Artist status refresh
6. Production PostgreSQL + object storage
7. Real DSP/distribution integrations

Audio va cover fayllari hozir server storage papkasida saqlanadi. Productionda S3-compatible object storage kabi yechimga o'tkazish tavsiya qilinadi.
